#!/bin/sh

set -e

if tty -s < /dev/fd/1 2> /dev/null; then
  GC='\e[0;32m'
  RC='\e[0;31m'
  NC='\e[0m'
fi

ROOT=`pwd -P`
[ -z "$DEST" ] && DEST="$ROOT"

###################
# Check for gmake #
###################
mkdir -p dist-bin
PATH=$PATH:$ROOT/dist-bin
ln -sf $(which make) $ROOT/dist-bin/gmake
ln -sf $ROOT/PkgConfig.pm $ROOT/dist-bin/pkg-config

export NUM_THREADS=`grep -c '^processor' /proc/cpuinfo 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 1`;
BINDIR=$DEST/bin
LIBDIR=$DEST/lib
export PKG_CONFIG_PATH=$LIBDIR/pkgconfig:$PKG_CONFIG_PATH
(cd global-1 && ./configure --prefix=$DEST --bindir=$BINDIR --libdir=$LIBDIR && make -j $NUM_THREADS install-special) && \
echo "Installing TransDecoder" && \
(cd $BINDIR && tar -xzf TransDecoder-v5.7.1a.tar.gz && rm -f  TransDecoder-v5.7.1a.tar.gz) && \
#echo "Installing samtools" && \
#(cd $BINDIR && tar -xzf samtools-1.15.1.tgz && cd samtools-1.15.1 && ./configure --prefix=$DEST --disable-lzma --without-curses && make -j; make install || echo -e "${RC}[WARNING!!! samtools installation failed, please make sure samtools are available on the system PATH for running EviAnn]${NC}" && cd .. && rm -rf  samtools-1.15.1.tgz samtools-1.15.1) && \
echo "Installing miniprot" && \
(cd $BINDIR && tar -xzf miniprot.tgz && cd miniprot_source && make && mv miniprot ../ && cd .. && rm -rf  miniprot_source miniprot.tgz) && \
echo "Installing SNAP" && \
(cd $BINDIR && tar -xzf snap.tgz && cd SNAP && make && mv fathom forge snap hmm-assembler.pl gff3_to_zff.pl ../ && cd .. && rm -rf SNAP snap.tgz) && \
echo "Checking static executables" && \
if [ $(bin/makeblastdb -h 1>/dev/null 2>&1; echo $?) -gt 0 ];then echo -e "${RC}[WARNING!!! installed makeblastdb, blastp executables are not compatible, please make sure they are available on the system PATH for running EviAnn; you can try downloading a version older than 2.2.31 from https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/]${NC}" && rm -f bin/{makeblastdb,blastp};fi
if [ $(bin/stringtie -h 1>/dev/null 2>&1; echo $?) -gt 0 ];then echo -e "${RC}[WARNING!!! installed stringtie executable is not compatible, please make sure stringtie is available on the system PATH for running EviAnn]${NC}" && rm -f bin/stringtie;fi
if [ $(bin/samtools --help 1>/dev/null 2>&1; echo $?) -gt 0 ];then echo -e "${RC}[WARNING!!! installed samtools executable is not compatible, please make sure samtools are available on the system PATH for running EviAnn]${NC}" && rm -f bin/samtools;fi
echo "Installation successful!" || echo "Installation failed"

